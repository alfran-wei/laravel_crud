<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>School Management Admin Website Templates | Preskool</title>

<link rel="shortcut icon" href="assets/img/favicon.png">

<meta name="description" content="Preskool is a Education Management Admin Template for schools/colleges with various features for all your needs. Try Demo and Buy Now!">
<meta name="keywords" content="school management template, education template, admin management template">
<meta name="author" content="dreamstechnologies">

<meta property="og:url" content="https://preschool.dreamstechnologies.com/">
<meta property="og:type" content="website">
<meta property="og:title" content="School Management Admin Website Templates | Preskool">
<meta property="og:description" content="Preskool is a Education Management Admin Template for schools/colleges with various features for all your needs. Try Demo and Buy Now!">
<meta property="og:image" content="/assets/img/preview-banner.jpg">

<meta name="twitter:card" content="summary_large_image">
<meta property="twitter:domain" content="https://preschool.dreamstechnologies.com/">
<meta property="twitter:url" content="https://preschool.dreamstechnologies.com/">
<meta name="twitter:title" content="School Management Admin Website Templates | Preskool">
<meta name="twitter:description" content="Preskool is a Education Management Admin Template for schools/colleges with various features for all your needs. Try Demo and Buy Now!">
<meta name="twitter:image" content="/assets/img/preview-banner.jpg">

<link rel="canonical" href="https://preschool.dreamstechnologies.com/">

<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">

<link rel="stylesheet" href="assets/css/feather.css">

<link rel="stylesheet" href="assets/plugins/aos/aos.css">

<link rel="stylesheet" href="assets/css/owl.carousel.min.css">

<link rel="stylesheet" href="assets/css/style.css">

<script type="5f98260456dd566df1d6ed99-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-KGQMVXR');</script>

</head>
<body>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KGQMVXR"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<div class="loader-main">
<span class="loader"></span>
</div>
<div class="main-wrapper">
<div class="main-banner">

<header class="header">
<div class="container">
<nav class="navbar navbar-expand-lg header-nav">
<div class="navbar-header">
<a id="mobile_btn" href="#">
<span class="bar-icon">
<span></span>
<span></span>
<span></span>
</span>
</a>
<a href="index.html" class="navbar-brand logo">
<img src="assets/img/logo.png" class="img-fluid" alt="Logo">
</a>
<a href="index.html" class="navbar-brand logo-small">
<img src="assets/img/logo.png" class="img-fluid" alt="Logo">
</a>
</div>
<div class="main-menu-wrapper">
<div class="menu-header">
<a href="index.html" class="menu-logo">
<img src="assets/img/logo.png" class="img-fluid" alt="Logo">
</a>
<a id="menu_close" class="menu-close" href="#"> <i class="fas fa-times"></i></a>
</div>
<ul class="main-nav navbar-nav" id="scroll-nav">
<li class="nav-item"><a href="#index" class="nav-link active">Home</a></li>
<li class="nav-item"><a href="#pages" class="nav-link">Demos</a></li>
<li class="nav-item"><a href="#template" class="nav-link">Inner Pages</a></li>
<li class="nav-item"><a href="#features" class="nav-link">Features</a></li>
<li class="nav-item"><a href="#pricing" class="nav-link">Pricing</a></li>
<li class="nav-item"><a href="#faq" class="nav-link">FAQ</a></li>
<li class="nav-item has-submenu megamenu-main">
<a href="https://themeforest.net/user/dreamstechnologies/portfolio" target="_blank">Other Products <i class="fas fa-chevron-down"></i></a>
<ul class="submenu megamenu-full-width">
<li>
<div class="container">
<div class="col-lg-12">
<div class="product-more">
<div class="row d-flex align-items-center justify-content-between">
<div class="col-lg-6">
<h3>Other Products</h3>
</div>
<div class="col-auto">
<a class="purchase-now" href="https://themeforest.net/user/dreamstechnologies/portfolio" target="_blank">More Products</a>
</div>
</div>
</div>
</div>
<div class="submenu-product-group">
<div class="row">
<div class="col-lg-4 col-sm-12">
<div class="submenu-head">
<a href="https://themeforest.net/item/kofejob-laravel-bootstrap-template/32980886" target="_blank">
<div class="product-content">
<img src="assets/img/product/product-01.jpg" class="img-fluid" alt>
<h4>Kofejob</h4>
<p>HTML5, Angular, Reactjs, Vuejs, Laravel</p>
</div>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-12">
<div class="submenu-head">
<a href="https://themeforest.net/item/dreamspos-pos-inventory-management-admin-dashboard-template/38834413" target="_blank">
<div class="product-content">
<img src="assets/img/product/product-02.jpg" class="img-fluid" alt>
<h4>DreamsPOS</h4>
<p>HTML, Angular, Reactjs, Vuejs, Laravel</p>
</div>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-12">
<div class="submenu-head">
<a href="https://themeforest.net/item/doccure-doctor-appointment-booking-bootstrap-template-with-admin-dashboard/25180784" target="_blank">
<div class="product-content">
<img src="assets/img/product/product-03.jpg" class="img-fluid" alt>
<h4>Doccure</h4>
<p>HTML Template</p>
</div>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-12">
<div class="submenu-head">
<a href="https://themeforest.net/item/dreams-lms-online-course-html-template/38940428" target="_blank">
<div class="product-content">
<img src="assets/img/product/product-04.jpg" class="img-fluid" alt>
<h4>DreamsLMS</h4>
<p>Html + Laravel + Vuejs</p>
</div>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-12">
<div class="submenu-head">
<a href="https://themeforest.net/item/kanakku-bootstrap-admin-html-template/29436291" target="_blank">
<div class="product-content">
<img src="assets/img/product/product-05.jpg" class="img-fluid" alt>
<h4>Kanakku</h4>
<p>HTML, Angular, Reactjs, Vuejs, Laravel</p>
</div>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-12">
<div class="submenu-head">
<a href="https://themeforest.net/item/truelysell-bootstrap-html-template/28664989" target="_blank">
<div class="product-content">
<img src="assets/img/product/product-06.jpg" class="img-fluid" alt>
<h4>Truelysell</h4>
<p>HTML Angular Laravel VueJS ReactJS</p>
</div>
</a>
</div>
</div>
</div>
</div>
</div>
</li>
</ul>
</li>
</ul>
</div>
<ul class="nav header-navbar-rht">
<li class="nav-item">
<a class="btn btn-secondary" href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</li>
<li class="nav-item">
<a class="btn btn-primary" href="https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878" target="_blank">Purchase Template<i class="feather feather-arrow-right ms-2"></i></a>
</li>
</ul>
</nav>
</div>
</header>


<section class="hero-section" id="index">
<div class="section-bg">
<img src="assets/img/bg/banner-bg-02.png" alt="Bg Image">
</div>
<div class="container banner-hero">
<div class="home-banner">
<div class="row">
<div class="col-lg-6">
<div class="banner-content aos" data-aos="fade-right" data-aos-delay="400">
<div class="banner-content">
<ul class="template-features">
<li><a href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank"><img src="assets/img/icons/framework-icon-01.svg" alt="Html Icon"></a></li>
<li><a href="https://preschool.dreamstechnologies.com/laravel/template/public/" target="_blank"><img src="assets/img/icons/framework-icon-02.svg" alt="Laravel Icon"></a></li>
<li><a href="https://preschool.dreamstechnologies.com/angular/template/login/" target="_blank"><img src="assets/img/icons/framework-icon-03.svg" alt="Angular Icon"></a></li>
<li><a href="https://preschool.dreamstechnologies.com/react/admindashboard" target="_blank"><img src="assets/img/icons/framework-icon-04.svg" alt="React Icon"></a></li>
<li><a href="https://preschool.dreamstechnologies.com/vuejs/template/index" target="_blank"><img src="assets/img/icons/framework-icon-05.svg" alt="Vuejs Icon"></a></li>
<li><a href="https://nodejs.dreamstechnologies.com/preskool/template/login" target="_blank"><img src="assets/img/icons/framework-icon-06.svg" alt="nodejs Icon"></a></li>
</ul>
<h1><span class="head">PreSkool </span>- School and Education Management Admin Dashboard Template
</h1>
<p>PreSkool is a simple and easy-to-access management dashboard for education, including schools, colleges, and universities.</p>
<div class="banner-wrap-btn">
<div class="banner-btns">
<a class="btn btn-primary" href="https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878" target="_blank">Purchase Template<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="banner-img">
<img src="assets/img/banner-img-01.png" class="img-fluid banner-one" alt="Banner">
<img src="assets/img/banner-img-02.png" class="img-fluid banner-two" alt="Banner">
</div>
</div>
</div>
</div>
</div>
</section>

</div>
<div data-bs-spy="scroll" data-bs-target="#scroll-nav" class="scrollspy-example" tabindex="0">

<section class="inner-page" id="pages">
<div class="section-bg">
<img src="assets/img/bg/section-bg-02.png" class="img-fluid right-bg" alt="Img">
</div>
<div class="container">
<div class="tech-info">
<h5><span>6 in 1 Bundle Pack ! </span> Choose technology that suits your convenience.</h5>
</div>
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Dashboard <span>Variations</span></h2>
</div>
<p>We build this template with HTML5,Angular,Vuejs Laravel and Nodejs.</p>
</div>
<div class="user-tab text-center">
<ul class="nav nav-pills inner-tab " id="pills-tab" role="tablist">
<li class="nav-item" role="presentation">
<button class="nav-link active" id="pills-admin-tab" data-bs-toggle="pill" data-bs-target="#pills-admin" type="button" role="tab" aria-controls="pills-admin" aria-selected="false"><i class="feather feather-settings me-2"></i>Admin Dashboard</button>
</li>
<li class="nav-item" role="presentation">
<button class="nav-link" id="pills-teacher-tab" data-bs-toggle="pill" data-bs-target="#pills-teacher" type="button" role="tab" aria-controls="pills-teacher" aria-selected="true"><i class="feather feather-user me-2"></i>Teacher Dashboard</button>
</li>
<li class="nav-item" role="presentation">
<button class="nav-link" id="pills-student-tab" data-bs-toggle="pill" data-bs-target="#pills-student" type="button" role="tab" aria-controls="pills-student" aria-selected="false"><i class="feather feather-edit-2 me-2"></i>Students Dashboard</button>
</li>
</ul>
<div class="tab-content dashboard-tab">
<div class="tab-pane fade show active" id="pills-admin" role="tabpanel" aria-labelledby="pills-admin-tab">
<div class="row">
<div class="col-lg-6 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<div class="overlay-color">
<img src="assets/img/inner-pages/dashboard-01.jpg" class="img-fluid" alt="Img">
<ul class="template-features">
<li><a href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank"><img src="assets/img/icons/framework-icon-01.svg" alt="Html Icon"><span>Html</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/laravel/template/public/index" target="_blank"><img src="assets/img/icons/framework-icon-02.svg" alt="Laravel Icon"><span>Laravel</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/angular/template/dashboard/main" target="_blank"><img src="assets/img/icons/framework-icon-03.svg" alt="Angular Icon"><span>Angular </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/react/admindashboard" target="_blank"><img src="assets/img/icons/framework-icon-04.svg" alt="React Icon"><span>React </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/vuejs/template/index" target="_blank"><img src="assets/img/icons/framework-icon-05.svg" alt="Vuejs Icon"><span>Vuejs </span></a></li>
<li><a href="https://nodejs.dreamstechnologies.com/preskool/template/index?" target="_blank"><img src="assets/img/icons/framework-icon-06.svg" alt="nodejs Icon"><span>Nodejs </span></a></li>
</ul>
</div>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/index.html">
<h3>Admin Dashboard</h3>
<h6>LTR</h6>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<div class="overlay-color">
<img src="assets/img/inner-pages/dashboard-02.jpg" class="img-fluid" alt="Img">
<ul class="template-features">
<li><a href="https://preschool.dreamstechnologies.com/template-rtl/index.html" target="_blank"><img src="assets/img/icons/framework-icon-01.svg" alt="Html Icon"><span>Html</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/laravel/template-rtl/public/index" target="_blank"><img src="assets/img/icons/framework-icon-02.svg" alt="Laravel Icon"><span>Laravel</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/angular/template-rtl/dashboard/main" target="_blank"><img src="assets/img/icons/framework-icon-03.svg" alt="Angular Icon"><span>Angular </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/react-rtl/admindashboard" target="_blank"><img src="assets/img/icons/framework-icon-04.svg" alt="React Icon"><span>React </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/vuejs/template-rtl/index" target="_blank"><img src="assets/img/icons/framework-icon-05.svg" alt="Vuejs Icon"><span>Vuejs </span></a></li>
<li><a href="https://nodejs.dreamstechnologies.com/preskool/template-rtl/index?" target="_blank"><img src="assets/img/icons/framework-icon-06.svg" alt="nodejs Icon"><span>Nodejs </span></a></li>
</ul>
</div>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/index.html">
<h3>Admin Dashboard</h3>
<h6>RTL</h6>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="tab-pane fade" id="pills-teacher" role="tabpanel" aria-labelledby="pills-teacher-tab">
<div class="row">
<div class="col-lg-6 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<div class="overlay-color">
<img src="assets/img/inner-pages/dashboard-03.jpg" class="img-fluid" alt="Img">
<ul class="template-features">
<li><a href="https://preschool.dreamstechnologies.com/template/teacher-dashboard.html" target="_blank"><img src="assets/img/icons/framework-icon-01.svg" alt="Html Icon"><span>Html</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/laravel/template/public/teacher-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-02.svg" alt="Laravel Icon"><span>Laravel</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/angular/template/dashboard/teacher" target="_blank"><img src="assets/img/icons/framework-icon-03.svg" alt="Angular Icon"><span>Angular </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/react/teacherdashboard" target="_blank"><img src="assets/img/icons/framework-icon-04.svg" alt="React Icon"><span>React </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/vuejs/template/teacher-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-05.svg" alt="Vuejs Icon"><span>Vuejs </span></a></li>
<li><a href="https://nodejs.dreamstechnologies.com/preskool/template/teacher-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-06.svg" alt="nodejs Icon"><span>Nodejs </span></a></li>
</ul>
</div>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/index.html">
<h3>Teacher Dashboard</h3>
<h6>LTR</h6>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<div class="overlay-color">
<img src="assets/img/inner-pages/dashboard-04.jpg" class="img-fluid" alt="Img">
<ul class="template-features">
<li><a href="https://preschool.dreamstechnologies.com/template-rtl/teacher-dashboard.html" target="_blank"><img src="assets/img/icons/framework-icon-01.svg" alt="Html Icon"><span>Html</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/laravel/template-rtl/public/teacher-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-02.svg" alt="Laravel Icon"><span>Laravel</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/angular/template-rtl/dashboard/teacher" target="_blank"><img src="assets/img/icons/framework-icon-03.svg" alt="Angular Icon"><span>Angular </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/react-rtl/teacherdashboard" target="_blank"><img src="assets/img/icons/framework-icon-04.svg" alt="React Icon"><span>React </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/vuejs/template-rtl/teacher-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-05.svg" alt="Vuejs Icon"><span>Vuejs </span></a></li>
<li><a href="https://nodejs.dreamstechnologies.com/preskool/template-rtl/teacher-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-06.svg" alt="nodejs Icon"><span>Nodejs </span></a></li>
</ul>
</div>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/index.html">
<h3>Teacher Dashboard</h3>
<h6>RTL</h6>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="tab-pane fade" id="pills-student" role="tabpanel" aria-labelledby="pills-student-tab">
<div class="row">
<div class="col-lg-6 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<div class="overlay-color">
<img src="assets/img/inner-pages/dashboard-05.jpg" class="img-fluid" alt="Img">
<ul class="template-features">
<li><a href="https://preschool.dreamstechnologies.com/template/student-dashboard.html" target="_blank"><img src="assets/img/icons/framework-icon-01.svg" alt="Html Icon"><span>Html</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/laravel/template/public/student-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-02.svg" alt="Laravel Icon"><span>Laravel</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/angular/template/dashboard/student" target="_blank"><img src="assets/img/icons/framework-icon-03.svg" alt="Angular Icon"><span>Angular </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/react/studentdashboard" target="_blank"><img src="assets/img/icons/framework-icon-04.svg" alt="React Icon"><span>React </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/vuejs/template/student-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-05.svg" alt="Vuejs Icon"><span>Vuejs </span></a></li>
<li><a href="https://nodejs.dreamstechnologies.com/preskool/template/student-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-06.svg" alt="nodejs Icon"><span>Nodejs </span></a></li>
</ul>
</div>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/index.html">
<h3>Student Dashboard</h3>
<h6>LTR</h6>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<div class="overlay-color">
<img src="assets/img/inner-pages/dashboard-06.jpg" class="img-fluid" alt="Img">
<ul class="template-features">
<li><a href="https://preschool.dreamstechnologies.com/template-rtl/student-dashboard.html" target="_blank"><img src="assets/img/icons/framework-icon-01.svg" alt="Html Icon"><span>Html</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/laravel/template-rtl/public/student-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-02.svg" alt="Laravel Icon"><span>Laravel</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/angular/template-rtl/dashboard/student" target="_blank"><img src="assets/img/icons/framework-icon-03.svg" alt="Angular Icon"><span>Angular </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/react-rtl/studentdashboard" target="_blank"><img src="assets/img/icons/framework-icon-04.svg" alt="React Icon"><span>React </span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/vuejs/template-rtl/student-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-05.svg" alt="Vuejs Icon"><span>Vuejs </span></a></li>
<li><a href="https://nodejs.dreamstechnologies.com/preskool/template-rtl/student-dashboard" target="_blank"><img src="assets/img/icons/framework-icon-06.svg" alt="nodejs Icon"><span>Nodejs </span></a></li>
</ul>
</div>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/index.html">
<h3>Student Dashboard</h3>
<h6>RTL</h6>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="available-features">
<div class="section-bg">
<img src="assets/img/bg/section-bg-03.png" class="img-fluid vector-line" alt="Img">
<img src="assets/img/bg/section-bg-04.png" class="img-fluid vector-triangle" alt="Img">
</div>
<div class="container">
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Available <span> Versions</span></h2>
</div>
<p>In order to get the files of the HTML 5, Laravel 10, Angular 16, React, Vue JS 3, Node JS</p>
</div>
<div class="row justify-content-center">
<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
<div class="available-framework text-center">
<div class="framework-img">
<a href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank"><img src="assets/img/icons/demo-icon-01.svg" class="img-fluid" alt="Html"></a>
</div>
<div class="buy-template">
<a href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>
<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
<div class="available-framework text-center">
<div class="framework-img laravel-img">
<a href="https://preschool.dreamstechnologies.com/laravel/template/public/" target="_blank"><img src="assets/img/icons/demo-icon-02.svg" class="img-fluid" alt="Laravel"></a>
</div>
<div class="buy-template">
<a href="https://preschool.dreamstechnologies.com/laravel/template/public/" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>
<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
<div class="available-framework text-center">
<div class="framework-img nord-img">
<a href="https://nodejs.dreamstechnologies.com/preskool/template/login" target="_blank"><img src="assets/img/icons/demo-icon-03.svg" class="img-fluid" alt="Node"></a>
</div>
<div class="buy-template">
<a href="https://nodejs.dreamstechnologies.com/preskool/template/login" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
<span class="badge latest-update">New</span>
</div>
</div>
<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
<div class="available-framework text-center">
<div class="framework-img angular-img">
<a href="https://preschool.dreamstechnologies.com/angular/template/login" target="_blank"><img src="assets/img/icons/demo-icon-04.svg" class="img-fluid" alt="Angular"></a>
</div>
<div class="buy-template">
<a href="https://preschool.dreamstechnologies.com/angular/template/login" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>
<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
<div class="available-framework text-center">
<div class="framework-img react-img">
<a href="https://preschool.dreamstechnologies.com/react/admindashboard" target="_blank"><img src="assets/img/icons/demo-icon-05.svg" class="img-fluid" alt="React"></a>
</div>
<div class="buy-template">
<a href="https://preschool.dreamstechnologies.com/react/admindashboard" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
<span class="badge latest-update">New</span>
</div>
</div>
<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
<div class="available-framework text-center">
<div class="framework-img vue-img">
<a href="https://preschool.dreamstechnologies.com/vuejs/template/index" target="_blank"><img src="assets/img/icons/demo-icon-06.svg" class="img-fluid" alt="Vue"></a>
</div>
<div class="buy-template">
<a href="https://preschool.dreamstechnologies.com/vuejs/template/index" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="why-choose">
<div class="container">
<div class="row">
<div class="col-lg-6">
<div class="section-header aos" data-aos="fade-up">
<div class="title-bar">
<h2>Why Choose <span> Preskool</span></h2>
</div>
<p>Preskool includes multiple awesomely designed and carefully crafted applications which enable you to get started and build your applications faster.</p>
</div>
<ul class="framework-features">
<li><i class="fa-solid fa-circle-check me-2"></i>100+ Pages</li>
<li><i class="fa-solid fa-circle-check me-2"></i>80+ Widgets</li>
<li><i class="fa-solid fa-circle-check me-2"></i>Invoice Design</li>
<li><i class="fa-solid fa-circle-check me-2"></i>200+ Components</li>
<li><i class="fa-solid fa-circle-check me-2"></i>Multiple Filters</li>
<li><i class="fa-solid fa-circle-check me-2"></i>Fees Structures</li>
<li><i class="fa-solid fa-circle-check me-2"></i>Customized UI Interface</li>
</ul>
<div class="banner-wrap-btn">
<div class="banner-btns">
<a class="btn btn-secondary" href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
<div class="banner-btns">
<a class="btn btn-primary" href="https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878" target="_blank">Purchase Template<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="section-img">
<img src="assets/img/section-img-01.png" class="img-fluid" alt="Img">
</div>
</div>
</div>
</div>
</section>


<section class="multiple-templates" id="template">
<div class="section-bg">
<img src="assets/img/bg/section-bg-02.png" class="img-fluid right-bg" alt="Img">
<img src="assets/img/bg/section-bg-05.png" class="img-fluid lef-bottom-bg" alt="Img">
</div>
<div class="container">
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Preskool <span> Other Pages</span></h2>
</div>
<p>Preskool template includes various features for providers such as student list, teachers list, department,etc.</p>
</div>
<div class="user-tab text-center">
<ul class="nav nav-pills inner-tab " id="pills-tab2" role="tablist">
<li class="nav-item" role="presentation">
<button class="nav-link active" id="pills-all-page-tab" data-bs-toggle="pill" data-bs-target="#pills-all-page" type="button" role="tab" aria-controls="pills-all-page" aria-selected="true"><i class="feather feather-layers me-2"></i>All Pages</button>
</li>
<li class="nav-item" role="presentation">
<button class="nav-link" id="pills-main-page-tab" data-bs-toggle="pill" data-bs-target="#pills-main-page" type="button" role="tab" aria-controls="pills-main-page" aria-selected="false"><i class="feather feather-link me-2"></i>Main Pages</button>
</li>
<li class="nav-item" role="presentation">
<button class="nav-link" id="pills-management-tab" data-bs-toggle="pill" data-bs-target="#pills-management" type="button" role="tab" aria-controls="pills-management" aria-selected="false"><i class="feather feather-user me-2"></i>Management</button>
</li>
<li class="nav-item" role="presentation">
<button class="nav-link" id="pills-authentication-tab" data-bs-toggle="pill" data-bs-target="#pills-authentication" type="button" role="tab" aria-controls="pills-authentication" aria-selected="false"><i class="feather feather-unlock me-2"></i>Authentication</button>
</li>
<li class="nav-item" role="presentation">
<button class="nav-link" id="pills-other-page-tab" data-bs-toggle="pill" data-bs-target="#pills-other-page" type="button" role="tab" aria-controls="pills-other-page" aria-selected="false"><i class="feather feather-tag me-2"></i>Other Pages</button>
</li>
</ul>
<div class="tab-content other-pages-tab">
<div class="tab-pane fade show active" id="pills-all-page" role="tabpanel" aria-labelledby="pills-all-page-tab">
<div class="row align-items-center text-center justify-content-center">
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/students.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-01.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/students.html" target="_blank">
<h3>Students</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/teachers.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-02.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/teachers.html" target="_blank">
<h3>Teachers</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/departments.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-03.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/departments.html" target="_blank">
<h3>Departments</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/sports.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-04.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/sports.html" target="_blank">
<h3>Sports</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/event.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-05.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/event.html" target="_blank">
<h3>Events</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/blog.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-06.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/blog.html" target="_blank">
<h3>Blogs</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/fees-collections.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-01.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/fees-collections.html" target="_blank">
<h3>Accounts</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/fees.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-07.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/fees.html" target="_blank">
<h3>Fees</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/exam.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-08.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/exam.html" target="_blank">
<h3>Exam list</h3>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="tab-pane fade" id="pills-main-page" role="tabpanel" aria-labelledby="pills-main-page-tab">
<div class="row align-items-center text-center justify-content-center">
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/students.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-01.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/students.html" target="_blank">
<h3>Students</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/teachers.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-02.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/teachers.html" target="_blank">
<h3>Teachers</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/departments.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-03.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/departments.html" target="_blank">
<h3>Departments</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/invoices.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-13.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/invoices.html" target="_blank">
<h3>Invoices</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/subjects.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-12.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/subjects.html" target="_blank">
<h3>Subjects</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/student-details.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-14.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/student-details.html" target="_blank">
<h3>Student Profile</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/teacher-details.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-11.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/teacher-details.html" target="_blank">
<h3>Teacher Profile</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/add-student.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-10.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/add-student.html" target="_blank">
<h3>Add Students</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/add-teacher.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-09.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/add-teacher.html" target="_blank">
<h3>Add Teachers</h3>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="tab-pane fade" id="pills-management" role="tabpanel" aria-labelledby="pills-management-tab">
<div class="row align-items-center text-center justify-content-center">
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/fees-collections.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-15.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/fees-collections.html" target="_blank">
<h3>Fees Collection</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/expenses.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-16.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/expenses.html" target="_blank">
<h3>Expenses</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/salary.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-17.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/salary.html" target="_blank">
<h3>Salary</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/holiday.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-18.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/holiday.html" target="_blank">
<h3>Holiday</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/fees.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-19.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/fees.html" target="_blank">
<h3>Fees</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/exam.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-20.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/exam.html" target="_blank">
<h3>Exam</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/event.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-21.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/event.html" target="_blank">
<h3>Events</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/time-table.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-22.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/time-table.html" target="_blank">
<h3>Time Table</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/library.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-23.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/library.html" target="_blank">
<h3>Library</h3>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="tab-pane fade" id="pills-authentication" role="tabpanel" aria-labelledby="pills-authentication-tab">
<div class="row align-items-center text-center justify-content-center">
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/login.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-24.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/login.html" target="_blank">
<h3>Log in</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/register.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-25.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/register.html" target="_blank">
<h3>Register</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/forgot-password.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-26.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/forgot-password.html" target="_blank">
<h3>Forgot Password</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/error-404.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-27.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/error-404.html" target="_blank">
<h3>404 Page</h3>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="tab-pane fade" id="pills-other-page" role="tabpanel" aria-labelledby="pills-other-page-tab">
<div class="row align-items-center text-center justify-content-center">
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/sports.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-31.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/sports.html" target="_blank">
<h3>Sports</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/hostel.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-28.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/hostel.html" target="_blank">
<h3>Hostel</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/transport.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-29.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/transport.html" target="_blank">
<h3>Transport</h3>
</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 d-flex justify-content-center" data-aos="fade-down">
<div class="inner-item">
<div class="inner-img">
<a href="https://preschool.dreamstechnologies.com/template/blog.html" target="_blank">
<img src="assets/img/inner-pages/inner-page-30.jpg" class="img-fluid" alt="Img">
</a>
</div>
<div class="inner-content">
<div class="inner-content-left text-center">
<a href="https://preschool.dreamstechnologies.com/template/blog.html" target="_blank">
<h3>Blog</h3>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="banner-wrap-btn justify-content-center">
<div class="banner-btns">
<a class="btn btn-secondary" href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank">More Pages<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>
</div>
</section>

<div class="looking-something">
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Looking for something about Preskool</h2>
</div>
</div>
<div class="banner-wrap-btn justify-content-center">
<div class="banner-btns">
<a class="btn btn-secondary btn-orange" href="https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878/support" target="_blank"><i class="feather feather-headphones me-2"></i>Support</a>
</div>
<div class="banner-btns">
<a class="btn btn-secondary btn-black" href="https://preschool.dreamstechnologies.com/documentation/index.html" target="_blank"><i class="feather feather-file-text me-2"></i>Online Documentation</a>
</div>

</div>
</div>

<section class="feature-offers">
<div class="container">
<div class="row">
<div class="col-lg-4">
<div class="section-img">
<img src="assets/img/section-img-02.png" class="img-fluid" alt="Img">
</div>
</div>
<div class="col-lg-8 position-relative">
<div class="section-header aos" data-aos="fade-up">
<div class="title-bar">
<h2>Features <span> Offered </span></h2>
</div>
<p>Preskool template includes various features for providers such as student list, teachers list, department,etc.</p>
</div>
<div class="row">
<div class="col-md-6">
<ul class="feature-lists">
<li>
<div class="feature-icon-box">
<i class="feather feather-lock"></i>
</div>
<div class="feature-type">
<h4>Login and User registration</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
<li>
<div class="feature-icon-box">
<i class="feather feather-calendar"></i>
</div>
<div class="feature-type">
<h4>Events management</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
<li>
<div class="feature-icon-box">
<i class="feather feather-clock"></i>
</div>
<div class="feature-type">
<h4>Timetable management</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
<li>
<div class="feature-icon-box">
<i class="feather feather-file-text"></i>
</div>
<div class="feature-type">
<h4>Account Management</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
</ul>
</div>
<div class="col-md-6">
<ul class="feature-lists">
<li>
<div class="feature-icon-box">
<i class="fa-solid fa-rocket"></i>
</div>
<div class="feature-type">
<h4>SEO Friendly</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
<li>
<div class="feature-icon-box">
<i class="feather feather-send"></i>
</div>
<div class="feature-type">
<h4>Transport management</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
<li>
<div class="feature-icon-box">
<i class="feather feather-bookmark"></i>
</div>
<div class="feature-type">
<h4>Library management</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
<li>
<div class="feature-icon-box">
<i class="feather feather-list"></i>
</div>
<div class="feature-type">
<h4>Subjects Management</h4>
<p>Id mollis consectetur congue egestas egessuspendisse blandit justo.</p>
</div>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="price-section price-sec" id="pricing">
<div class="container">
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Preskool <span> Pricing</span></h2>
</div>
<p>Preskool template includes various features for providers such as student list, teachers list, department,etc.</p>
</div>
<div class="row justify-content-center">
<div class="col-xl-4 col-md-6 d-flex aos" data-aos="fade-up">
<div class="pricing-wrap img-price text-center w-100 d-flex align-items-end justify-content-center">
<div class="pricing-img">
<img src="assets/img/pricing-img.png" class="img-fluid" alt="Img">
</div>
</div>
</div>
<div class="col-xl-4 col-md-6 d-flex aos" data-aos="fade-up">
<div class="pricing-wrap w-100">
<div class="price-head">
<div class="price-icon text-center">
<img src="assets/img/icons/price-icon-01.svg" alt="Img">
</div>
<div class="price-title">
<div class="price-info">
<h5>Regular License<i class="feather feather-info ms-2"></i></h5>
</div>
<div class="price-sticker">
<img src="assets/img/icons/price-sticker.svg" alt="Img">
</div>
</div>
<div class="price-dollar d-flex align-items-center">
<h3>$24</h3>
</div>
</div>
<div class="price-body">
<ul class="price-check">
<li>Included : Quality checked by Envato</li>
<li>Included : Future updates</li>
<li>6 months support from the author</li>
<li class="feature-none">Nec ac sagittis nunc bibendum</li>
<li class="feature-none">Odio ut orci volutpat ultricies eleifend</li>
</ul>
<a href="https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878" class="btn btn-secondary" target="_blank">Choose Plan</a>
</div>
</div>
</div>
<div class="col-xl-4 col-md-6 d-flex aos" data-aos="fade-up">
<div class="pricing-wrap w-100">
<div class="price-head">
<div class="price-icon text-center">
<img src="assets/img/icons/price-icon-02.svg" alt="Img">
</div>
<div class="price-title">
<div class="price-info">
<h5>Extended License<i class="feather feather-info ms-2"></i></h5>
</div>
</div>
<div class="price-dollar d-flex align-items-center">
<h3>$349</h3>
</div>
</div>
<div class="price-body">
<ul class="price-check">
<li>Included : Quality checked by Envato</li>
<li>Included : Future updates</li>
<li>6 months support from the author</li>
<li class="feature-none">6 months support from the author</li>
<li class="feature-none">Odio ut orci volutpat ultricies eleifend</li>
</ul>
<a href="https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878" class="btn btn-secondary" target="_blank">Choose Plan</a>
</div>
</div>
</div>
</div>
</div>
</section>

<section class="trusted-developer">
<div class="container">
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Trusted by Developers From All Over the World</h2>
</div>
<p>Kickstart your project, save thousands of hours, and level up as a developer.</p>
</div>
<div class="row justify-content-center">
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="counter-box">
<h4><span class="counter animated fadeInDownBig">9000 </span> + </h4>
<h5>Lines of Code</h5>
</div>
</div>
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="counter-box">
<h4><span class="counter animated fadeInDownBig">80 </span> + </h4>
<h5>Hours of Work</h5>
</div>
</div>
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="counter-box">
<h4><span class="counter animated fadeInDownBig">15 </span> k </h4>
<h5>Trusted Customers</h5>
</div>
</div>
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="counter-box">
<h4><span class="counter animated fadeInDownBig">100 </span> % </h4>
<h5>Customer Satisfaction</h5>
</div>
</div>
</div>
</div>
</section>
<section class="client-review">
<div class="container">
<div class="row">
<div class="col-lg-3">
<div class="section-header aos" data-aos="fade-up">
<div class="title-bar">
<h2>What Our Clients Say About Us:</h2>
<div class="owl-nav mynav nav-control"></div>
</div>
</div>
</div>
<div class="col-lg-9">
<div class="review-slider owl-carousel">
<div class="client-review-field">
<div class="review-card">
<div class="quate">
<i class="fa-solid fa-quote-left"></i>
</div>
<p>I solved my issue with support team members. appreciated it. sorry for the inconvenience.</p>
<h6>Customer Support</h6>
<span>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</span>
</div>
<div class="client-info">
<img src="assets/img/icons/review-client-img.svg" alt="Img">
<h5><a href="#">zulyarkurban</a></h5>
</div>
</div>
<div class="client-review-field">
<div class="review-card">
<div class="quate">
<i class="fa-solid fa-quote-left"></i>
</div>
<p>Awesome Template. helps me a lot. and quick response from the team.</p>
<h6>Customer Support</h6>
<span>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</span>
</div>
<div class="client-info">
<img src="assets/img/icons/review-client-img.svg" alt="Img">
<h5><a href="#">willscott356</a></h5>
</div>
</div>
<div class="client-review-field">
<div class="review-card">
<div class="quate">
<i class="fa-solid fa-quote-left"></i>
</div>
<p>good code, quite helpful.</p>
<h6>Customer Support</h6>
<span>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</span>
</div>
<div class="client-info">
<img src="assets/img/icons/review-client-img.svg" alt="Img">
<h5><a href="#">gihan_weerasinghe</a></h5>
</div>
</div>
<div class="client-review-field">
<div class="review-card">
<div class="quate">
<i class="fa-solid fa-quote-left"></i>
</div>
<p>I solved my issue with support team members. appreciated it. sorry for the inconvenience.</p>
<h6>Customer Support</h6>
<span>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</span>
</div>
<div class="client-info">
<img src="assets/img/icons/review-client-img.svg" alt="Img">
<h5><a href="#">zulyarkurban</a></h5>
</div>
</div>
</div>
</div>
</div>
<div class="request-demo">
<div class="section-bg">
<img src="assets/img/bg/section-bg-08.png" alt="Img">
</div>
<div class="row">
<div class="col-lg-6">
<div class="section-header align-items-start aos" data-aos="fade-up">
<div class="title-bar">
<h2>Request a <span> Demo</span></h2>
</div>
<p>Like what you have seen? Let’s get started. Just fill in a few details and we will get in touch as soon as possible.</p>
</div>
<form method="post" id="contact_form">
<div class="row">
<div class="col-lg-6">
<div class="input-block">
<label>First name</label>
<input type="text" id="first_name" name="first_name" class="form-control" autocomplete="off" required>
</div>
</div>
<div class="col-lg-6">
<div class="input-block">
<label>Last name</label>
<input type="text" id="last_name" name="last_name" class="form-control" autocomplete="off" required>
</div>
</div>
<div class="col-lg-6">
<div class="input-block">
<label>Email address</label>
<input type="email" id="email" name="email" class="form-control" autocomplete="off" required>
</div>
</div>
<div class="col-lg-6">
<div class="input-block">
<label>Phone</label>
<input type="text" id="phone_num" name="phone_num" class="form-control" minlength="7" maxlength="15" autocomplete="off" required>
</div>
</div>
<div class="col-lg-12">
<div class="input-block">
<label>Your Comments</label>
<textarea rows="5" class="form-control" rows="4" name="comments" placeholder="Your Comments here" id="comments" required></textarea>
</div>
</div>
</div>
<button class="btn btn-primary" onclick="if (!window.__cfRLUnblockHandlers) return false; emailcreate()" data-cf-modified-5f98260456dd566df1d6ed99->Submit Enquiry</button>
</form>
</div>
<div class="col-lg-6">
<div class="section-img">
<img src="assets/img/section-img-03.png" alt="Img">
</div>
</div>
</div>
</div>
</div>
</section>

<section class="faq-section" id="faq">
<div class="container">
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Frequently Asked Question</h2>
</div>
<p>Preskool template includes various features for providers such as student list, teachers list, department,etc.</p>
</div>
<div class="row justify-content-center" id="accordionExample">
<div class="col-lg-10 text-center">
<div class="faq-card aos" data-aos="fade-up">
<h4 class="faq-title">
<a class data-bs-toggle="collapse" href="#faqOne" aria-expanded="false"> What if I don't have any professional background?</a>
</h4>
<div id="faqOne" class="card-collapse collapse show" data-bs-parent="#accordionExample">
<p>You can sell and accept payments in many currencies, depending on what payment providers (also known as third party payment processors or payment gateways) you use.</p>
</div>
</div>
<div class="faq-card aos" data-aos="fade-up">
<h4 class="faq-title">
<a class="collapsed" data-bs-toggle="collapse" href="#faqtwo" aria-expanded="false">How is this different from other courses on the market?</a>
</h4>
<div id="faqtwo" class="card-collapse collapse" data-bs-parent="#accordionExample">
<p>You can sell and accept payments in many currencies, depending on what payment providers (also known as third party payment processors or payment gateways) you use.</p>
</div>
</div>
<div class="faq-card aos" data-aos="fade-up">
<h4 class="faq-title">
<a class="collapsed" data-bs-toggle="collapse" href="#faqthree" aria-expanded="false"> How much time does it take to do my homework per week? What if I don't like it?</a>
</h4>
<div id="faqthree" class="card-collapse collapse" data-bs-parent="#accordionExample">
<p>In simple terms, Extended License means your end product may be sold or otherwise limited to paying customers.</p>
</div>
</div>
<div class="faq-card aos" data-aos="fade-up">
<h4 class="faq-title">
<a class="collapsed" data-bs-toggle="collapse" href="#faqfour" aria-expanded="false"> Is there any kind of certificate of completion?</a>
</h4>
<div id="faqfour" class="card-collapse collapse" data-bs-parent="#accordionExample">
<p>In simple terms, Extended License means your end product may be sold or otherwise limited to paying customers.</p>
</div>
</div>
<div class="faq-card aos" data-aos="fade-up">
<h4 class="faq-title">
<a class="collapsed" data-bs-toggle="collapse" href="#faqfive" aria-expanded="false"> YouTube is full of free tutorials, videos and courses. Why should I take?</a>
</h4>
<div id="faqfive" class="card-collapse collapse" data-bs-parent="#accordionExample">
<p>You can sell and accept payments in many currencies, depending on what payment providers (also known as third party payment processors or payment gateways) you use.</p>
</div>
</div>
<div class="faq-card aos" data-aos="fade-up">
<h4 class="faq-title">
<a class="collapsed" data-bs-toggle="collapse" href="#faqsix" aria-expanded="false">Is there any kind of certificate of completion?</a>
</h4>
<div id="faqsix" class="card-collapse collapse" data-bs-parent="#accordionExample">
<p>You can sell and accept payments in many currencies, depending on what payment providers (also known as third party payment processors or payment gateways) you use.</p>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="core-section" id="features">
<div class="container">
<div class="section-header text-center aos" data-aos="fade-up">
<div class="title-bar">
<h2>Features of <span>Template</span></h2>
</div>
<p>All the features every great theme has.</p>
</div>
<div class="row justify-content-center">
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-01.svg">
</div>
<h5>Bootstrap</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-02.svg">
</div>
<h5>Fully Responsive</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-03.svg">
</div>
<h5>Gulp Workflow</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-04.svg">
</div>
<h5>Multiple Demos</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-05.svg">
</div>
<h5>Pure Javascript</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-06.svg">
</div>
<h5>Cross Browser</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-07.svg">
</div>
<h5>SASS Support</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-08.svg">
</div>
<h5>Quick Support</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-09.svg">
</div>
<h5>Well Documentation</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-10.svg">
</div>
<h5>Dark & Light Layouts</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-11.svg">
</div>
<h5>RTL Layout</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-12.svg">
</div>
<h5>Easy Customization</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-13.svg">
</div>
<h5>Lifetime Updates</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-14.svg">
</div>
<h5>Quality Code</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-15.svg">
</div>
<h5>Premade Layouts</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-16.svg">
</div>
<h5>Light Weighted</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-17.svg">
</div>
<h5>Speed Performance</h5>
</div>
</div>
<div class="col-xl-2 col-md-3 col-sm-4 d-flex  justify-content-center">
<div class="core-feature aos" data-aos="fade-up">
<div class="core-icon">
<img class="img-fluid" alt="icon" src="assets/img/icons/feature-icon-18.svg">
</div>
<h5>Retina Ready</h5>
</div>
</div>
</div>
</div>
</section>


<section class="customization-sec">
<div class="container">
<div class="customize-top">
<div class="section-bg">
<img src="assets/img/bg/section-bg-06.png" class="customize-bg" alt="Img">
</div>
<div class="section-header">
<h2>Need a customized application
for your business?</h2>
<p>We (Dreams Technologies) are happy to customise your products based on your needs, send us a note</p>
</div>
<div class="contact-btns d-flex">
<a href="#" class="btn btn-primary"><i class="feather-calendar me-2"></i>Book an Appointment</a>
<a href="#" class="btn btn-secondary m-0"><i class="feather-file-text me-2"></i>Get a Free Quote</a>
</div>
<div class="section-img">
<img src="assets/img/section-img-04.png" class="img-fluid" alt="Img">
</div>
</div>
</div>
</section>


<footer class="footer">
<div class="section-bg">
<img src="assets/img/bg/section-bg-07.png" class="footer-bg" alt="Img">
</div>

<div class="footer-top aos" data-aos="fade-up">
<div class="container">
<div class="row">
<div class="col-lg-12">

<div class="footer-widget author-logo">
<ul>
<li class="elite-author">
<a href="#">
<img src="assets/img/icons/author-01.svg" alt="logo">
</a>
<h6>Elite Author</h6>
</li>
<li class="tendset">
<a href="#">
<img src="assets/img/icons/author-02.svg" alt="logo">
</a>
<h6>Trendsetter</h6>
</li>
<li class="author-level">
<a href="#">
<img src="assets/img/icons/author-03.svg" alt="logo">
</a>
<h6>Author Level</h6>
</li>
</ul>
<div class="footer-content">
<h2>Build your School & Education Management Admin Dashboard Template with <span>Preskool</span></h2>
</div>
<div class="banner-wrap-btn justify-content-center">
<div class="banner-btns">
<a class="btn btn-secondary" href="https://preschool.dreamstechnologies.com/template/index.html" target="_blank">Live Demo<i class="feather feather-arrow-right ms-2"></i></a>
</div>
<div class="banner-btns">
<a class="btn btn-primary" href="https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878" target="_blank">Purchase Template<i class="feather feather-arrow-right ms-2"></i></a>
</div>
</div>
</div>

</div>
</div>
</div>
</div>


<div class="footer-bottom">

<div class="copyright footer-bottom-text">
<div class="row align-items-center">
<div class="col-lg-3">
<div class="social-icon">
<ul>
<li>
<a href=" https://www.facebook.com/dreamstechnologieslimited" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
</li>
<li>
<a href="https://www.instagram.com/dreamstechnologieslimited/" target="_blank"><i class="fa-brands fa-instagram"></i></a>
</li>
<li>
<a href="https://www.behance.net/dreamstechnologies" target="_blank"><i class="fa-brands fa-behance"></i></a>
</li>
<li>
<a href="https://twitter.com/dreamstechltd" target="_blank"><i class="fab fa-twitter"></i> </a>
</li>
<li>
<a href="https://www.linkedin.com/company/dreamstechnologies" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
</li>
</ul>
</div>
</div>
<div class="col-lg-6">

<div class="footer-widget footer-menu">
<ul>
<li>
<a href="https://themeforest.net/legal/market" target="_blank">Term of use</a>
</li>
<li>
<a href="https://themeforest.net/licenses/standard" target="_blank">License</a>
</li>
<li>
<a href="https://themeforest.net/page/customer_refund_policy" target="_blank">Refund Policy</a>
</li>
<li>
<a href="https://preschool.dreamstechnologies.com/documentation/index.html" target="_blank">Documentation</a>
</li>
<li>
<a href="https://preschool.dreamstechnologies.com/documentation/changelog.html" target="_blank">Logs</a>
</li>
</ul>
</div>

</div>
<div class="col-lg-3">
<div class="copyright-text">
<p class="mb-0"> Copyright Year - 2013 - <script type="5f98260456dd566df1d6ed99-text/javascript">
											document.write(new Date().getFullYear())
									  
											</script> </p>
</div>
</div>
</div>
</div>

</div>

</footer>

</div>
<div class="mouse-cursor cursor-outer"></div>
<div class="mouse-cursor cursor-inner"></div>
<div class="back-to-top">
<a class="back-to-top-icon align-items-center justify-content-center d-flex" href="#top"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
</div>
</div>

<script src="assets/js/jquery-3.7.1.min.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>

<script src="assets/js/bootstrap.bundle.min.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>
<script src="assets/js/bootstrap-scrollspy.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>

<script src="assets/js/feather.min.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>

<script src="assets/plugins/aos/aos.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>

<script src="assets/js/jquery.waypoints.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>
<script src="assets/js/jquery.counterup.min.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>

<script src="assets/js/owl.carousel.min.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>

<script src="assets/js/script.js" type="5f98260456dd566df1d6ed99-text/javascript"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-YY0YK6GN6S" type="5f98260456dd566df1d6ed99-text/javascript"></script>
<script type="5f98260456dd566df1d6ed99-text/javascript">
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());

	gtag('config', 'G-YY0YK6GN6S');
	</script>

<script type="5f98260456dd566df1d6ed99-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-WX6MN22');</script>

<script type="5f98260456dd566df1d6ed99-text/javascript">
		var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
		(function(){
		var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
		s1.async=true;
		s1.src='https://embed.tawk.to/5d7c946e9f6b7a4457e1a16b/default';
		s1.charset='UTF-8';
		s1.setAttribute('crossorigin','*');
		s0.parentNode.insertBefore(s1,s0);
		})();
	</script>
<script type="application/ld+json">
		{
		  "@context": "https://schema.org/", 
		  "@type": "Product", 
		  "name": "PreSkool",
		  "image": "https://preschool.dreamguystech.com/assets/img/logo.png",
		  "description": "School Management HTML Admin Template",
		  "brand": {
			"@type": "Brand",
			"name": "PreSkool"
		  },
		  "offers": {
			"@type": "Offer",
			"url": "https://themeforest.net/item/preskool-bootstrap-admin-html-template/29532878",
			"priceCurrency": "USD",
			"price": "24"
		  }
		}
	</script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="5f98260456dd566df1d6ed99-|49" defer></script></body>
</html>